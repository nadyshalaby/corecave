<?php

/**
 * Define a custom exception class
 */

namespace App\Libs\Exceptions;

use Exception;

class MassAssignException extends Exception {
    
}
