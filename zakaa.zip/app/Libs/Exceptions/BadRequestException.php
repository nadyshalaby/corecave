<?php

/**
 * Define a custom exception class
 */

namespace App\Libs\Exceptions;

use Exception;

class BadRequestException extends Exception {
    
}
