<?php

validate()->clearErrors();