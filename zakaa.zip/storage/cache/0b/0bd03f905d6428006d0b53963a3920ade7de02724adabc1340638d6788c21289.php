<?php

/* admin/templates/msg-modal-template.html */
class __TwigTemplate_95ce4f52da0092fd846f2b9277ba7d2dc809c81180cbf9fd788278d473554b06 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"row\">
    <div class=\"form-group col-sm-12\">
        <div class=\"row\">
            <div class=\"form-group col-sm-6\">
                <label>Name</label>
                <span class=\"form-control\">{name}</span>      
            </div>
            <div class=\"form-group col-sm-6\">
                <label>Email </label>
                <span class=\"form-control\">{from}</span>        
            </div>
        </div>
        <div class=\"row\">
            <div class=\"form-group col-sm-6\">
                <label>Subject</label>
                <span class=\"form-control\">{subject}</span>      
            </div>
            <div class=\"form-group col-sm-6\">
                <label>Date </label>
                <span class=\"form-control\">{created_at}</span>        
            </div>
        </div>
        <div class=\"row\">
            <div class=\"form-group col-sm-12\">
                <label>Message</label>
                <span class=\"form-control\">{body}</span>          
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "admin/templates/msg-modal-template.html";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <div class="row">*/
/*     <div class="form-group col-sm-12">*/
/*         <div class="row">*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Name</label>*/
/*                 <span class="form-control">{name}</span>      */
/*             </div>*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Email </label>*/
/*                 <span class="form-control">{from}</span>        */
/*             </div>*/
/*         </div>*/
/*         <div class="row">*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Subject</label>*/
/*                 <span class="form-control">{subject}</span>      */
/*             </div>*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Date </label>*/
/*                 <span class="form-control">{created_at}</span>        */
/*             </div>*/
/*         </div>*/
/*         <div class="row">*/
/*             <div class="form-group col-sm-12">*/
/*                 <label>Message</label>*/
/*                 <span class="form-control">{body}</span>          */
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* </div>*/
