<?php

/* admin/templates/order-row-template.html */
class __TwigTemplate_df479b1bbdf2d45f7274ca647bf99f80c05bbfbdd0254b514efff4de276510bd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<tr class=\"{seen}\" data-order-id=\"{id}\" >
    <td class=\"ID\">
        <input name=\"ids[]\" class=\"chk-box\" value=\"{id}\" type=\"checkbox\">
    </td>
    <td>{plan}</td>
    <td>{firstname} {lastname}</td>
    <td>{email}</td>
    <td>{country}</td>
    <td>{state}</td>
    <td><small>{created_at}</small></td>
    <td>{status}</td>
    <td>
        <button type=\"button\" class=\"btn btn-info btn-sm btn-order-view\" data-order-id=\"{id}\" data-toggle=\"modal\" data-target=\"#modal-orders\"> 
            <i class=\"fa fa-eye\"></i>
            View
        </button>
    </td>
</tr>";
    }

    public function getTemplateName()
    {
        return "admin/templates/order-row-template.html";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <tr class="{seen}" data-order-id="{id}" >*/
/*     <td class="ID">*/
/*         <input name="ids[]" class="chk-box" value="{id}" type="checkbox">*/
/*     </td>*/
/*     <td>{plan}</td>*/
/*     <td>{firstname} {lastname}</td>*/
/*     <td>{email}</td>*/
/*     <td>{country}</td>*/
/*     <td>{state}</td>*/
/*     <td><small>{created_at}</small></td>*/
/*     <td>{status}</td>*/
/*     <td>*/
/*         <button type="button" class="btn btn-info btn-sm btn-order-view" data-order-id="{id}" data-toggle="modal" data-target="#modal-orders"> */
/*             <i class="fa fa-eye"></i>*/
/*             View*/
/*         </button>*/
/*     </td>*/
/* </tr>*/
