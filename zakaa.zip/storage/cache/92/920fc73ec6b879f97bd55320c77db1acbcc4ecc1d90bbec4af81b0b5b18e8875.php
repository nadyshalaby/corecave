<?php

/* admin/templates/msg-row-template.html */
class __TwigTemplate_8afea1d8e7ad45fbd1c49e5559de7e6f67641b34b993d1c162192da4d6ac613d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
<tr class=\"{seen}\">
     <td class=\"ID\">
         <input name=\"ids[]\" class=\"chk-box\" value=\"{id}\" type=\"checkbox\">
     </td>
     <td>{name}</td>
     <td>{from}</td>
     <td><small>{created_at}</small></td>
     <td>{subject}</td>
     <td><p>{body}</p></td>
     <td>
         <button type=\"button\" class=\"btn btn-info btn-sm btn-msg-view\" data-toggle=\"modal\" data-msg-id=\"{id}\" data-target=\"#modal-message\"> 
             <i class=\"fa fa-eye\"></i>
             View
         </button>
     </td>
 </tr>";
    }

    public function getTemplateName()
    {
        return "admin/templates/msg-row-template.html";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* */
/* <tr class="{seen}">*/
/*      <td class="ID">*/
/*          <input name="ids[]" class="chk-box" value="{id}" type="checkbox">*/
/*      </td>*/
/*      <td>{name}</td>*/
/*      <td>{from}</td>*/
/*      <td><small>{created_at}</small></td>*/
/*      <td>{subject}</td>*/
/*      <td><p>{body}</p></td>*/
/*      <td>*/
/*          <button type="button" class="btn btn-info btn-sm btn-msg-view" data-toggle="modal" data-msg-id="{id}" data-target="#modal-message"> */
/*              <i class="fa fa-eye"></i>*/
/*              View*/
/*          </button>*/
/*      </td>*/
/*  </tr>*/
