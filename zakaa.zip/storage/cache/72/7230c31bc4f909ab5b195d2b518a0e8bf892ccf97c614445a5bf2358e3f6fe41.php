<?php

/* admin/templates/order-modal-template.html */
class __TwigTemplate_914dc48ccf1252c723c661286e1f46c3b58c232f4049e9a804f999c028e72601 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"row\">
    <div class=\"col-sm-12\">
        <div class=\"tap modal-body-header\">
            <ul class=\"nav nav-pills\" role=\"tablist\">
                <li role=\"presentation\" class=\"active\"><a href=\"#sectionBasicData\" aria-controls=\"sectionBasicData\" role=\"tab\" data-toggle=\"tab\"><span class=\"badge\">1</span> Basic Data</a>
                </li>
                <li role=\"presentation\"><a href=\"#sectionContacts\" aria-controls=\"sectionContacts\" role=\"tab\" data-toggle=\"tab\"><span class=\"badge\">2</span>Contacts</a></li>
                <li role=\"presentation\"><a href=\"#sectionOthers\" aria-controls=\"sectionOthers\" role=\"tab\" data-toggle=\"tab\"><span class=\"badge\">3</span> Others </a></li>

            </ul>
        </div>
    </div>
</div>             
<div class=\"tab-content\" >
    <section role=\"tabpanel\" class=\"basic-data tab-pane active\" id=\"sectionBasicData\">
        <div class=\"row\">
            <div class=\"form-group col-sm-6\">
                <label>First Name</label>
                <span class=\"form-control\">{firstname}</span>  
            </div>
            <div class=\"form-group col-sm-6\">
                <label>Last Name</label>
                <span class=\"form-control\">{lastname}</span>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"form-group col-sm-6\">
                <label>Social Number</label>
                <span class=\"form-control\">{social_number}</span>      
            </div>
            <div class=\"form-group col-sm-6\">
                <label>Plan</label>
                <span class=\"form-control\">{plan}</span>
            </div>
        </div>
    </section>
    <section role=\"tabpanel\" class=\"contacts tab-pane\" id=\"sectionContacts\">
        <div class=\"row\">
            <div class=\"form-group col-sm-6\">
                <label>Telephone</label>
                <span class=\"form-control\">{tel}</span>         
            </div>
            <div class=\"form-group col-sm-6\">
                <label>Mobile</label>
                <span class=\"form-control\">{mobile}</span>                  
            </div>
        </div>
        <div class=\"row\">
            <div class=\"form-group col-sm-6\">
                <label>Address 1</label>
                <span class=\"form-control\">{address_1}</span>               
            </div>
            <div class=\"form-group col-sm-6\">
                <label>Address 2</label>
                <span class=\"form-control\">{address_2}</span>           
            </div>
        </div>
        <div class=\"row\">
            <div class=\"form-group col-sm-4\">
                <label>Country</label>
                <span class=\"form-control\">{country}</span>

            </div>
            <div class=\"form-group col-sm-4\">
                <label>State</label>
                <span class=\"form-control\">{state}</span>              
            </div>
            <div class=\"form-group col-sm-4\">
                <label>city</label>
                <span class=\"form-control\">{city}</span>                        
            </div>
        </div>
        <div class=\"row\">    
            <div class=\"form-group col-sm-6\">
                <label>Email</label>
                <span class=\"form-control\">{email}</span>                    
            </div>
            <div class=\"form-group col-sm-6\">
                <label>Website</label>
                <span class=\"form-control\">{website}</span>                            
            </div>
        </div>
    </section>
    <section role=\"tabpanel\" class=\"sectionOthers tab-pane\" id=\"sectionOthers\">
        <div class=\"row\">
            <div class=\"form-group col-sm-6\">
                <label>Project Name</label>
                <span class=\"form-control\">{project_name}</span>               
            </div>
            <div class=\"form-group col-sm-6\">
                <label>Attachment</label>
                <a href=\"";
        // line 92
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url_translate')->getCallable(), array("download/")), "html", null, true);
        echo "{attachment}\" class=\"btn btn-primary\">{attachment}</a>               
            </div>
        </div>
        <div class=\"row\">
            <div class=\"form-group col-sm-12\">
                <label>Description</label>
                <span class=\"form-control\">{description}</span>
            </div>
        </div>
    </section>
</div>";
    }

    public function getTemplateName()
    {
        return "admin/templates/order-modal-template.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 92,  19 => 1,);
    }
}
/* <div class="row">*/
/*     <div class="col-sm-12">*/
/*         <div class="tap modal-body-header">*/
/*             <ul class="nav nav-pills" role="tablist">*/
/*                 <li role="presentation" class="active"><a href="#sectionBasicData" aria-controls="sectionBasicData" role="tab" data-toggle="tab"><span class="badge">1</span> Basic Data</a>*/
/*                 </li>*/
/*                 <li role="presentation"><a href="#sectionContacts" aria-controls="sectionContacts" role="tab" data-toggle="tab"><span class="badge">2</span>Contacts</a></li>*/
/*                 <li role="presentation"><a href="#sectionOthers" aria-controls="sectionOthers" role="tab" data-toggle="tab"><span class="badge">3</span> Others </a></li>*/
/* */
/*             </ul>*/
/*         </div>*/
/*     </div>*/
/* </div>             */
/* <div class="tab-content" >*/
/*     <section role="tabpanel" class="basic-data tab-pane active" id="sectionBasicData">*/
/*         <div class="row">*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>First Name</label>*/
/*                 <span class="form-control">{firstname}</span>  */
/*             </div>*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Last Name</label>*/
/*                 <span class="form-control">{lastname}</span>*/
/*             </div>*/
/*         </div>*/
/*         <div class="row">*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Social Number</label>*/
/*                 <span class="form-control">{social_number}</span>      */
/*             </div>*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Plan</label>*/
/*                 <span class="form-control">{plan}</span>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/*     <section role="tabpanel" class="contacts tab-pane" id="sectionContacts">*/
/*         <div class="row">*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Telephone</label>*/
/*                 <span class="form-control">{tel}</span>         */
/*             </div>*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Mobile</label>*/
/*                 <span class="form-control">{mobile}</span>                  */
/*             </div>*/
/*         </div>*/
/*         <div class="row">*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Address 1</label>*/
/*                 <span class="form-control">{address_1}</span>               */
/*             </div>*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Address 2</label>*/
/*                 <span class="form-control">{address_2}</span>           */
/*             </div>*/
/*         </div>*/
/*         <div class="row">*/
/*             <div class="form-group col-sm-4">*/
/*                 <label>Country</label>*/
/*                 <span class="form-control">{country}</span>*/
/* */
/*             </div>*/
/*             <div class="form-group col-sm-4">*/
/*                 <label>State</label>*/
/*                 <span class="form-control">{state}</span>              */
/*             </div>*/
/*             <div class="form-group col-sm-4">*/
/*                 <label>city</label>*/
/*                 <span class="form-control">{city}</span>                        */
/*             </div>*/
/*         </div>*/
/*         <div class="row">    */
/*             <div class="form-group col-sm-6">*/
/*                 <label>Email</label>*/
/*                 <span class="form-control">{email}</span>                    */
/*             </div>*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Website</label>*/
/*                 <span class="form-control">{website}</span>                            */
/*             </div>*/
/*         </div>*/
/*     </section>*/
/*     <section role="tabpanel" class="sectionOthers tab-pane" id="sectionOthers">*/
/*         <div class="row">*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Project Name</label>*/
/*                 <span class="form-control">{project_name}</span>               */
/*             </div>*/
/*             <div class="form-group col-sm-6">*/
/*                 <label>Attachment</label>*/
/*                 <a href="{{ url_translate('download/') }}{attachment}" class="btn btn-primary">{attachment}</a>               */
/*             </div>*/
/*         </div>*/
/*         <div class="row">*/
/*             <div class="form-group col-sm-12">*/
/*                 <label>Description</label>*/
/*                 <span class="form-control">{description}</span>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* </div>*/
