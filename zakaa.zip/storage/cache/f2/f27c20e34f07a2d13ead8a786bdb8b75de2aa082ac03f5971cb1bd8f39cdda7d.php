<?php

/* admin/pages/profile.html */
class __TwigTemplate_35008081d9e7b6e541e0706558710a4301d7aaf39d8023640c8015429363ef94 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/master.html ", "admin/pages/profile.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/master.html ";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "<section class=\"content\">
    <div class=\"panel panel-default\">
        <div class=\"panel-heading\">
            <h3 class=\"panel-head\">Hello, ";
        // line 7
        echo ((($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "gender", array()) == "male")) ? ("Mr") : ("Miss"));
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "fullname", array()), "html", null, true);
        echo " </h3>
        </div>
        <div class=\"panel-body\">
            <form role=\"form\" action=\"";
        // line 10
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url_route')->getCallable(), array("update")), "html", null, true);
        echo "\" id=\"account-form\" method=\"post\" enctype=\"multipart/form-data\">
                <div class=\"container-fluid text-center\">
                    <div class=\"col-xs-6 col-md-5 \">
                        <div class=\"panel panel-default\">
                            <!-- Default panel contents -->
                            <div class=\"panel-heading\">Personal</div>
                            <div class=\"panel-body\">
                                <p>
                                <ul class=\"list-group\">
                                    <li class=\"list-group-item\">
                                        <div class=\"input-group \">                         
                                            <span class=\"input-group-addon\" id=\"sizing-addon1\"><span class=\"glyphicon glyphicon-user\" aria-hidden=\"true\"></span></span>
                                            <input type=\"text\" class=\"form-control\" name=\"fullname\" placeholder=\"Full Name\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "fullname", array()), "html", null, true);
        echo "\" aria-describedby=\"sizing-addon1\">
                                        </div>
                                    </li>
                                    <li class=\"list-group-item\">
                                        <div class=\"input-group \">

                                            <span class=\"input-group-addon\" id=\"sizing-addon2\"><span class=\"glyphicon glyphicon-earphone\" aria-hidden=\"true\"></span></span>
                                            <input type=\"text\" class=\"form-control\" name=\"tel\" placeholder=\"Telephone\" value=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "tel", array()), "html", null, true);
        echo "\"aria-describedby=\"sizing-addon2\">
                                        </div>
                                    </li>
                                    <li class=\"list-group-item\">
                                        <div class=\"input-group \">

                                            <span class=\"input-group-addon\" id=\"sizing-addon3\"><span class=\"glyphicon glyphicon-phone\" aria-hidden=\"true\"></span></span>
                                            <input type=\"text\" class=\"form-control\" name=\"mobile\" placeholder=\"Mobile\" value=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "mobile", array()), "html", null, true);
        echo "\"aria-describedby=\"sizing-addon3\">
                                        </div>
                                    </li>
                                    <li class=\"list-group-item\">
                                        <div class=\"input-group \">

                                            <span class=\"input-group-addon\" id=\"sizing-addon4\"><span class=\"glyphicon glyphicon-map-marker\" aria-hidden=\"true\"></span></span>
                                            <input type=\"text\" class=\"form-control\" name=\"address\" placeholder=\"Address\" value=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "address", array()), "html", null, true);
        echo "\" aria-describedby=\"sizing-addon4\">
                                        </div>
                                    </li>
                                    <li class=\"list-group-item\">
                                        <div class=\"input-group \">

                                            <span class=\"input-group-addon\" id=\"sizing-addon5\"><span class=\"glyphicon glyphicon-envelope\" aria-hidden=\"true\"></span></span>
                                            <input type=\"email\" class=\"form-control\" name=\"email\" placeholder=\"Email\" value=\"";
        // line 50
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "email", array()), "html", null, true);
        echo "\"aria-describedby=\"sizing-addon5\">
                                        </div>
                                    </li>
                                    <li class=\"list-group-item\">
                                        <div class=\"input-group \">

                                            <span class=\"input-group-addon\" id=\"sizing-addon12\"><span class=\"glyphicon glyphicon-plane\" aria-hidden=\"true\"></span></span>
                                            <select name=\"gender\" class=\"form-control\">
                                                ";
        // line 58
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "gender", array()) == "male")) {
            // line 59
            echo "                                                <option value=\"male\" >male</option>
                                                <option value=\"female\" >female</option>                                         
                                                ";
        } else {
            // line 62
            echo "                                                <option value=\"female\" >female</option>                                         
                                                <option value=\"male\" >male</option>
                                                ";
        }
        // line 65
        echo "                                            </select>
                                        </div>
                                    </li>

                                </ul>
                                </p>
                            </div>


                        </div>
                    </div>
                    <div class=\"col-xs-6 col-md-4\">
                        <div class=\"panel panel-default\">
                            <!-- Default panel contents -->
                            <div class=\"panel-heading\">Credentials</div>
                            <div class=\"panel-body\">
                                <p>
                                <ul class=\"list-group\">                                      
                                    <li class=\"list-group-item\">
                                        <div class=\"input-group \">

                                            <span class=\"input-group-addon\" id=\"sizing-addon6\"><span class=\"glyphicon glyphicon-lock\" aria-hidden=\"true\"></span></span>
                                            <input type=\"password\" class=\"form-control\" name=\"pass\" placeholder=\"Current Password\" aria-describedby=\"sizing-addon6\">
                                        </div>
                                    </li>
                                    <li class=\"list-group-item\">
                                        <div class=\"input-group \">

                                            <span class=\"input-group-addon\" id=\"sizing-addon7\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></span>
                                            <input type=\"password\" class=\"form-control\" name=\"newpass\" placeholder=\"New Password\" aria-describedby=\"sizing-addon7\">
                                        </div>
                                    </li>
                                    <li class=\"list-group-item\">
                                        <div class=\"input-group \">

                                            <span class=\"input-group-addon\" id=\"sizing-addon8\"><span class=\"glyphicon glyphicon-refresh\" aria-hidden=\"true\"></span></span>
                                            <input type=\"password\" class=\"form-control\" name=\"repass\" placeholder=\"Confirm Password\" aria-describedby=\"sizing-addon8\">
                                        </div>
                                    </li>
                                </ul>
                                </p>
                            </div>
                        </div>
                        <div class=\"row\">
                            <div class=\"col-md-12\">
                                <div class=\"panel panel-default\">
                                    <!-- Default panel contents -->
                                    <div class=\"panel-heading\">Actions</div>
                                    <div class=\"panel-body\">
                                        <p>
                                        <ul class=\"list-group\">                                      
                                            <li class=\"list-group-item\">
                                                <button type=\"submit\" class=\"btn btn-primary\" >Update</button>
                                                <button type=\"button\" id=\"account-delete\" class=\"btn btn-danger\"  >Delete Account</button>
                                            </li>
                                        </ul>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                ";
        // line 128
        echo call_user_func_array($this->env->getFunction('token_put')->getCallable(), array());
        echo "
            </form>
        </div>
</section>
            
";
    }

    // line 134
    public function block_scripts($context, array $blocks = array())
    {
        // line 135
        echo "<script id=\"order-modal-template\" >";
        $this->loadTemplate("admin/templates/order-modal-template.html", "admin/pages/profile.html", 135)->display($context);
        echo "</script>
<script id=\"order-row-template\" >";
        // line 136
        $this->loadTemplate("admin/templates/order-row-template.html", "admin/pages/profile.html", 136)->display($context);
        echo "</script>
<script src=\"";
        // line 137
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url_pub')->getCallable(), array("admin/js/process.js")), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "admin/pages/profile.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  210 => 137,  206 => 136,  201 => 135,  198 => 134,  188 => 128,  123 => 65,  118 => 62,  113 => 59,  111 => 58,  100 => 50,  90 => 43,  80 => 36,  70 => 29,  60 => 22,  45 => 10,  37 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }
}
/* {% extends 'admin/master.html '%}*/
/* */
/* {% block content%}*/
/* <section class="content">*/
/*     <div class="panel panel-default">*/
/*         <div class="panel-heading">*/
/*             <h3 class="panel-head">Hello, {{ user.gender == 'male' ? 'Mr' : 'Miss' }} {{ user.fullname }} </h3>*/
/*         </div>*/
/*         <div class="panel-body">*/
/*             <form role="form" action="{{ url_route('update') }}" id="account-form" method="post" enctype="multipart/form-data">*/
/*                 <div class="container-fluid text-center">*/
/*                     <div class="col-xs-6 col-md-5 ">*/
/*                         <div class="panel panel-default">*/
/*                             <!-- Default panel contents -->*/
/*                             <div class="panel-heading">Personal</div>*/
/*                             <div class="panel-body">*/
/*                                 <p>*/
/*                                 <ul class="list-group">*/
/*                                     <li class="list-group-item">*/
/*                                         <div class="input-group ">                         */
/*                                             <span class="input-group-addon" id="sizing-addon1"><span class="glyphicon glyphicon-user" aria-hidden="true"></span></span>*/
/*                                             <input type="text" class="form-control" name="fullname" placeholder="Full Name" value="{{ user.fullname }}" aria-describedby="sizing-addon1">*/
/*                                         </div>*/
/*                                     </li>*/
/*                                     <li class="list-group-item">*/
/*                                         <div class="input-group ">*/
/* */
/*                                             <span class="input-group-addon" id="sizing-addon2"><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span></span>*/
/*                                             <input type="text" class="form-control" name="tel" placeholder="Telephone" value="{{ user.tel }}"aria-describedby="sizing-addon2">*/
/*                                         </div>*/
/*                                     </li>*/
/*                                     <li class="list-group-item">*/
/*                                         <div class="input-group ">*/
/* */
/*                                             <span class="input-group-addon" id="sizing-addon3"><span class="glyphicon glyphicon-phone" aria-hidden="true"></span></span>*/
/*                                             <input type="text" class="form-control" name="mobile" placeholder="Mobile" value="{{ user.mobile }}"aria-describedby="sizing-addon3">*/
/*                                         </div>*/
/*                                     </li>*/
/*                                     <li class="list-group-item">*/
/*                                         <div class="input-group ">*/
/* */
/*                                             <span class="input-group-addon" id="sizing-addon4"><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span></span>*/
/*                                             <input type="text" class="form-control" name="address" placeholder="Address" value="{{ user.address }}" aria-describedby="sizing-addon4">*/
/*                                         </div>*/
/*                                     </li>*/
/*                                     <li class="list-group-item">*/
/*                                         <div class="input-group ">*/
/* */
/*                                             <span class="input-group-addon" id="sizing-addon5"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span></span>*/
/*                                             <input type="email" class="form-control" name="email" placeholder="Email" value="{{ user.email }}"aria-describedby="sizing-addon5">*/
/*                                         </div>*/
/*                                     </li>*/
/*                                     <li class="list-group-item">*/
/*                                         <div class="input-group ">*/
/* */
/*                                             <span class="input-group-addon" id="sizing-addon12"><span class="glyphicon glyphicon-plane" aria-hidden="true"></span></span>*/
/*                                             <select name="gender" class="form-control">*/
/*                                                 {% if user.gender == 'male' %}*/
/*                                                 <option value="male" >male</option>*/
/*                                                 <option value="female" >female</option>                                         */
/*                                                 {% else %}*/
/*                                                 <option value="female" >female</option>                                         */
/*                                                 <option value="male" >male</option>*/
/*                                                 {% endif %}*/
/*                                             </select>*/
/*                                         </div>*/
/*                                     </li>*/
/* */
/*                                 </ul>*/
/*                                 </p>*/
/*                             </div>*/
/* */
/* */
/*                         </div>*/
/*                     </div>*/
/*                     <div class="col-xs-6 col-md-4">*/
/*                         <div class="panel panel-default">*/
/*                             <!-- Default panel contents -->*/
/*                             <div class="panel-heading">Credentials</div>*/
/*                             <div class="panel-body">*/
/*                                 <p>*/
/*                                 <ul class="list-group">                                      */
/*                                     <li class="list-group-item">*/
/*                                         <div class="input-group ">*/
/* */
/*                                             <span class="input-group-addon" id="sizing-addon6"><span class="glyphicon glyphicon-lock" aria-hidden="true"></span></span>*/
/*                                             <input type="password" class="form-control" name="pass" placeholder="Current Password" aria-describedby="sizing-addon6">*/
/*                                         </div>*/
/*                                     </li>*/
/*                                     <li class="list-group-item">*/
/*                                         <div class="input-group ">*/
/* */
/*                                             <span class="input-group-addon" id="sizing-addon7"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></span>*/
/*                                             <input type="password" class="form-control" name="newpass" placeholder="New Password" aria-describedby="sizing-addon7">*/
/*                                         </div>*/
/*                                     </li>*/
/*                                     <li class="list-group-item">*/
/*                                         <div class="input-group ">*/
/* */
/*                                             <span class="input-group-addon" id="sizing-addon8"><span class="glyphicon glyphicon-refresh" aria-hidden="true"></span></span>*/
/*                                             <input type="password" class="form-control" name="repass" placeholder="Confirm Password" aria-describedby="sizing-addon8">*/
/*                                         </div>*/
/*                                     </li>*/
/*                                 </ul>*/
/*                                 </p>*/
/*                             </div>*/
/*                         </div>*/
/*                         <div class="row">*/
/*                             <div class="col-md-12">*/
/*                                 <div class="panel panel-default">*/
/*                                     <!-- Default panel contents -->*/
/*                                     <div class="panel-heading">Actions</div>*/
/*                                     <div class="panel-body">*/
/*                                         <p>*/
/*                                         <ul class="list-group">                                      */
/*                                             <li class="list-group-item">*/
/*                                                 <button type="submit" class="btn btn-primary" >Update</button>*/
/*                                                 <button type="button" id="account-delete" class="btn btn-danger"  >Delete Account</button>*/
/*                                             </li>*/
/*                                         </ul>*/
/*                                         </p>*/
/*                                     </div>*/
/*                                 </div>*/
/*                             </div>*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*                 {{ token_put()|raw }}*/
/*             </form>*/
/*         </div>*/
/* </section>*/
/*             */
/* {% endblock %}*/
/* {% block scripts %}*/
/* <script id="order-modal-template" >{% include 'admin/templates/order-modal-template.html' %}</script>*/
/* <script id="order-row-template" >{% include 'admin/templates/order-row-template.html' %}</script>*/
/* <script src="{{ url_pub('admin/js/process.js') }}"></script>*/
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
/* */
/* */
/* */
/* */
/* */
